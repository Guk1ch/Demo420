﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vosmerka420.DB;

namespace Vosmerka420.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {
        private Product product;
        public static List<ProductType> productType { get; set; }

        public ProductPage()
        {
            InitializeComponent();
            ProductLV.ItemsSource = DBConnection.Vosmerka420Entities.Product.ToList();
            var type = DBConnection.Vosmerka420Entities.ProductType.ToList();
            type.Insert(0, new ProductType() { ID = 0, Title = "Все" });
            SortiCB.ItemsSource = type.ToList();
            SortiCB.DisplayMemberPath = "Title";
            this.DataContext = this;

        }



        private void AddProductBTN_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddProductPage());
        }

        private void SearchTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            //ProductLV.ItemsSource = DBConnection.Vosmerka420Entities.Product.Where(x => x.Title.ToLower().Contains(SearchTB.Text.ToLower())).ToList();
        }

        private void StatusCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var type = SortiCB.SelectedItem as ProductType;
            if (type.ID == 0)
            {
                ProductLV.ItemsSource = new List<Product>(DBConnection.Vosmerka420Entities.Product);
            }
            else
            {
                ProductLV.ItemsSource = new List<Product>(DBConnection.Vosmerka420Entities.Product.Where(i => i.ID == type.ID));
            }
        }

        private void EditProductBTN_Click(object sender, RoutedEventArgs e)
        {
            if (ProductLV.SelectedIndex != -1)
            {
                var SelectEmp = (Product)ProductLV.SelectedItem;
                EditProductPage editPage = new EditProductPage(SelectEmp);
                NavigationService.Navigate(editPage);
            }
            else
            {
                MessageBox.Show("Вы не выбрали продукт для изменения");
            }
        }
    }
}
