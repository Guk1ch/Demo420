﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vosmerka420.DB;

namespace Vosmerka420.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditProductPage.xaml
    /// </summary>
    public partial class EditProductPage : Page
    {
        private Product product;
        public static List<ProductType> productType { get; set; }
        public EditProductPage(Product selecPart)
        {
            InitializeComponent();
            product = selecPart;
            TypeCB.ItemsSource = DBConnection.Vosmerka420Entities.ProductType.ToList();
            TypeCB.DisplayMemberPath = "Title";
            AmountTB.Text = selecPart.MinCostForAgent.ToString();
            TypeCB.SelectedIndex = (int)(selecPart.ID - 1);
            this.DataContext = this;

        }

        private void BackBTN_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductPage());
        }

        private void EditProductBTN_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
