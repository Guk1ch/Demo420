﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vosmerka420.DB
{
    internal class DBConnection
    {
        public static Vosmerka420Entities Vosmerka420Entities = new Vosmerka420Entities();
    }
}
